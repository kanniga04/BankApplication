# Bank Management System in Java
A simple command-line project to simulate basic banking operations.
It allows the user to check balance, deposit money, and withdrawl money interactively.

## Featuers
 View the account balance
 Deposit money
 Withdraw money
 Exit the program

 ## How to Run
 1.Open the terminal in the 'src' folder.
 2.Compile the program.

 ## Created By
  Kanniga Parameswari M
